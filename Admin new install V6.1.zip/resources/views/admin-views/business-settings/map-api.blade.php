@extends('layouts.admin.app')

@section('title', translate('Map API Settings'))

@push('css_or_js')

@endpush

@section('content')
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            @include('admin-views.business-settings.partial.third-party-api-navmenu')
        </div>
        <!-- End Page Header -->


        <div class="card">
            <div class="card-body">
                <form action="{{env('APP_MODE')!='demo'?route('admin.business-settings.web-app.third-party.map-api-store'):'javascript:'}}" method="post">
                    @csrf
                    @php($key=\App\Model\BusinessSetting::where('key','map_api_key')->first()->value)
                    <div class="form-group">
                        <label class="form-label">{{translate('map_api')}} {{translate('key')}}</label>
                        <textarea name="map_api_key" class="form-control"
                                    >{{env('APP_MODE')!='demo'?$key:''}}</textarea>
                    </div>
                    <div class="btn--container justify-content-end">
                        <button class="btn btn--reset" type="reset">{{translate('reset')}}</button>
                        <button type="{{env('APP_MODE')!='demo'?'submit':'button'}}" onclick="{{env('APP_MODE')!='demo'?'':'call_demo()'}}" class="btn btn-primary">{{translate('save')}}</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
@endsection


